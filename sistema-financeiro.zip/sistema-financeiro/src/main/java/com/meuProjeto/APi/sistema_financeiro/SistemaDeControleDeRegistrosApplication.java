package com.meuProjeto.APi.sistema_financeiro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaDeControleDeRegistrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaDeControleDeRegistrosApplication.class, args);
	}

}

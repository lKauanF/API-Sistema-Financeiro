package com.meuProjeto.sistema_financeiro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaDeControleDeRegistrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
